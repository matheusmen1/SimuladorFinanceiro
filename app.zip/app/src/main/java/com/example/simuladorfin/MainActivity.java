package com.example.simuladorfin;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private EditText etValor;
    private SeekBar sbPrazo, sbJuros;
    private TextView tvPrazo, tvJuros, tvParcela;

    private double parcela=0,valor,juros;
    private int prazo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //binding com os componentes da interface
        etValor=findViewById(R.id.etValor);
        sbPrazo=findViewById(R.id.sbPrazo);
        sbJuros=findViewById(R.id.sbJuros);
        tvPrazo=findViewById(R.id.tvPrazo);
        tvJuros=findViewById(R.id.tvJuros);
        tvParcela=findViewById(R.id.tvParcela);
        etValor.setText("5000.00");
        calcParcela();
        //gerando eventos
        sbPrazo.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                tvPrazo.setText(""+i);
                calcParcela();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        sbJuros.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                tvJuros.setText(""+(i/100.));
                calcParcela();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        etValor.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int i, KeyEvent keyEvent) {
                calcParcela();
                return false;
            }
        });

    }
    private void calcParcela(){
        if(!etValor.getText().toString().isEmpty())
            valor=Double.parseDouble(etValor.getText().toString());
        else
            valor=0;
        prazo=sbPrazo.getProgress();
        juros=sbJuros.getProgress()/100.0;
        parcela=calcParcela(valor,juros,prazo);
        tvParcela.setText(String.format("%.2f",parcela));
    }
    private double calcParcela(double valor, double juros, int prazo){
        return valor*(juros/100/(1-Math.pow(1+juros/100,prazo*-1)));
    }
}